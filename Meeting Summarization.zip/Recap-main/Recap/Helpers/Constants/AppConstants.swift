import Foundation

struct AppConstants {
    struct Logging {
        static let subsystem = "com.recap.audio"
    }
}